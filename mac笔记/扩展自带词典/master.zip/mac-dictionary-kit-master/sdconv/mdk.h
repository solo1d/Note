// mdk.h: main include file for Mac Dictionary Kit

#ifndef MDK_H
#define MDK_H

#include "dict.h"
#include "convert.h"

#endif

