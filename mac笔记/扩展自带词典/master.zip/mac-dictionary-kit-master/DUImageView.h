//
//  DUImageView.h
//  DictUnifier
//
//  Created by Jjgod Jiang on 3/11/10.
//

#import <Cocoa/Cocoa.h>
#import "DictUnifierAppDelegate.h"

@interface DUImageView : NSImageView {
    IBOutlet DictUnifierAppDelegate *controller;
}

@end
