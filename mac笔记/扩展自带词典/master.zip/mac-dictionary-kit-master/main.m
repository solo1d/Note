//
//  main.m
//  DictUnifier
//
//  Created by Jiang Jiang on 3/7/10.
//  Copyright Jjgod Jiang 2010. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc, (const char **) argv);
}
