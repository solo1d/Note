//
//  DUWindow.h
//  DictUnifier
//
//  Created by Jjgod Jiang on 3/11/10.
//

#import <Cocoa/Cocoa.h>
#import "DictUnifierAppDelegate.h"

@interface DUWindow : NSWindow {
    IBOutlet DictUnifierAppDelegate *controller;
}

@end
